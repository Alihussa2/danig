using Grpc.Core;
using Library.Grpc.Protos;
using Microsoft.EntityFrameworkCore;
// Både Library.Data og Library.Grpc.Protos har en klasse "Book".
// Derfor importeres Library.Data ikke helt; vi henter kun det, vi skal bruge, med alias.
// "Book" betyder herefter altid gRPC-beskeden, "BookEntity" er databasens række.
using LibraryContext = Library.Data.LibraryContext;
using BookEntity = Library.Data.Book;

namespace Library.Grpc.Services;

// Implementerer servicen fra Protos/library.proto.
// LibraryService.LibraryServiceBase bliver genereret af Grpc.Tools ved build.
public class LibraryGrpcService(
    LibraryContext db,
    BookBroadcaster broadcaster,
    ILogger<LibraryGrpcService> logger) : LibraryService.LibraryServiceBase
{
    // ---------- Unary: GetBookById ----------

    public override async Task<Book> GetBookById(GetBookByIdRequest request, ServerCallContext context)
    {
        var book = await db.Books.AsNoTracking()
            .FirstOrDefaultAsync(b => b.Id == request.Id, context.CancellationToken);

        if (book is null)
            throw new RpcException(new Status(StatusCode.NotFound, $"Book {request.Id} does not exist."));

        return ToMessage(book);
    }

    // ---------- Unary: CreateBook ----------

    public override async Task<CreateBookResponse> CreateBook(CreateBookRequest request, ServerCallContext context)
    {
        await Validate(request, context.CancellationToken);

        var entity = new BookEntity
        {
            Title = request.Title.Trim(),
            AuthorId = request.AuthorId,
            PublisherId = request.PublisherId,
            PublishingYear = request.PublishingYear
        };
        db.Books.Add(entity);
        await db.SaveChangesAsync(context.CancellationToken);

        var book = ToMessage(entity);

        // Giv besked til alle, der lytter på WatchBooks
        broadcaster.Publish(book);
        logger.LogInformation("Book {Id} created, sent to {Count} watcher(s)", book.Id, broadcaster.SubscriberCount);

        return new CreateBookResponse { Id = book.Id, Book = book };
    }

    // ---------- Server streaming: WatchBooks ----------

    public override async Task WatchBooks(WatchBooksRequest request, IServerStreamWriter<Book> responseStream, ServerCallContext context)
    {
        var (id, reader) = broadcaster.Subscribe();
        logger.LogInformation("Watcher {Id} connected ({Count} total)", id, broadcaster.SubscriberCount);

        try
        {
            // Venter på nye bøger, indtil klienten afbryder (CancellationToken udløses)
            await foreach (var book in reader.ReadAllAsync(context.CancellationToken))
                await responseStream.WriteAsync(book);
        }
        catch (OperationCanceledException)
        {
            // Klienten har lukket streamen – helt normalt
        }
        finally
        {
            broadcaster.Unsubscribe(id);
            logger.LogInformation("Watcher {Id} disconnected", id);
        }
    }

    // ---------- Hjælpere ----------

    private static Book ToMessage(BookEntity b) => new()
    {
        Id = b.Id,
        Title = b.Title,
        AuthorId = b.AuthorId,
        PublisherId = b.PublisherId,
        PublishingYear = b.PublishingYear
    };

    // Samme regler som REST. I proto3 bliver manglende felter "" eller 0,
    // så de fanges af de samme tjek. Fejl -> StatusCode.InvalidArgument.
    private async Task Validate(CreateBookRequest r, CancellationToken ct)
    {
        var errors = new List<string>();

        if (string.IsNullOrWhiteSpace(r.Title))
            errors.Add("title is required.");
        else if (r.Title.Trim().Length > 255)
            errors.Add("title must be at most 255 characters.");

        if (r.PublishingYear < 1900)
            errors.Add("publishing_year must be 1900 or later.");

        if (!await db.Authors.AnyAsync(a => a.Id == r.AuthorId, ct))
            errors.Add($"author_id {r.AuthorId} does not reference an existing author.");

        if (!await db.Publishers.AnyAsync(p => p.Id == r.PublisherId, ct))
            errors.Add($"publisher_id {r.PublisherId} does not reference an existing publisher.");

        if (errors.Count > 0)
            throw new RpcException(new Status(StatusCode.InvalidArgument, string.Join(" ", errors)));
    }
}
