using System.Collections.Concurrent;
using System.Threading.Channels;
using Library.Grpc.Protos;

namespace Library.Grpc.Services;

// Holder styr på alle klienter, der kalder WatchBooks.
// Hver abonnent får sin egen kø (Channel). Når en bog oprettes, lægges den i alle køerne.
// Registreres som singleton, så alle kald deler samme instans.
public class BookBroadcaster
{
    private readonly ConcurrentDictionary<Guid, Channel<Book>> _subscribers = new();

    public (Guid Id, ChannelReader<Book> Reader) Subscribe()
    {
        var id = Guid.NewGuid();
        var channel = Channel.CreateUnbounded<Book>();
        _subscribers[id] = channel;
        return (id, channel.Reader);
    }

    public void Unsubscribe(Guid id)
    {
        if (_subscribers.TryRemove(id, out var channel))
            channel.Writer.TryComplete();
    }

    public void Publish(Book book)
    {
        foreach (var channel in _subscribers.Values)
            channel.Writer.TryWrite(book);
    }

    public int SubscriberCount => _subscribers.Count;
}
