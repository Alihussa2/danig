using Library.Data;
using Library.Grpc.Services;
//1
var builder = WebApplication.CreateBuilder(args);

// Samme database som REST: ../library.db (solution-mappen)
builder.Services.AddLibraryDb(builder.Environment.ContentRootPath);

builder.Services.AddGrpc();
builder.Services.AddGrpcReflection();

// Én fælles broadcaster for alle WatchBooks-abonnenter
builder.Services.AddSingleton<BookBroadcaster>();

var app = builder.Build();

app.MapGrpcService<LibraryGrpcService>();

// Gør det muligt for Postman/Rider at hente servicens metoder uden .proto-filen
app.MapGrpcReflectionService();

app.Run();
