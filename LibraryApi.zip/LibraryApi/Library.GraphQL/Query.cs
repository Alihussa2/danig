﻿using Library.Data;
using Microsoft.EntityFrameworkCore;

namespace Library.GraphQL;

public class Query
{
    // Get book by ID
    public async Task<Book?> GetBookById(int id, LibraryContext db) =>
        await db.Books
            .Include(b => b.Author)
            .Include(b => b.Publisher)
            .FirstOrDefaultAsync(b => b.Id == id);

    // List all authors (incl. their books, so "authors { books { title } }" works)
    public async Task<List<Author>> GetAuthors(LibraryContext db) =>
        await db.Authors
            .Include(a => a.Books)
            .OrderBy(a => a.Id)
            .ToListAsync();

    // List all publishers (incl. their books, so "publishers { books { title } }" works)
    public async Task<List<Publisher>> GetPublishers(LibraryContext db) =>
        await db.Publishers
            .Include(p => p.Books)
            .OrderBy(p => p.Id)
            .ToListAsync();
}