using Library.Data;
using Library.GraphQL;

var builder = WebApplication.CreateBuilder(args);

// Databasen fra Library.Data (library.db i solution-mappen)
builder.Services.AddLibraryDb(builder.Environment.ContentRootPath);

// GraphQL-serveren med vores Query og Mutation
builder.Services
    .AddGraphQLServer()
    .AddQueryType<Query>()
    .AddMutationType<Mutation>();

var app = builder.Build();

// POST-endpoint på /graphql
app.MapGraphQL();

app.Run();