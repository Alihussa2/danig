﻿using HotChocolate;
using Library.Data;
using Microsoft.EntityFrameworkCore;

namespace Library.GraphQL;

public class Mutation
{
    // ---------- Books ----------

    public async Task<Book> CreateBook(string title, int authorId, int publisherId, int publishingYear, LibraryContext db)
    {
        await ValidateBook(title, authorId, publisherId, publishingYear, db);

        var book = new Book
        {
            Title = title,
            AuthorId = authorId,
            PublisherId = publisherId,
            PublishingYear = publishingYear
        };
        db.Books.Add(book);
        await db.SaveChangesAsync();

        return await LoadBook(book.Id, db);
    }

    public async Task<Book> UpdateBook(int id, string title, int authorId, int publisherId, int publishingYear, LibraryContext db)
    {
        var book = await db.Books.FindAsync(id) ?? throw NotFound("Book", id);
        await ValidateBook(title, authorId, publisherId, publishingYear, db);

        book.Title = title;
        book.AuthorId = authorId;
        book.PublisherId = publisherId;
        book.PublishingYear = publishingYear;
        await db.SaveChangesAsync();

        return await LoadBook(id, db);
    }

    public async Task<bool> DeleteBook(int id, LibraryContext db)
    {
        var book = await db.Books.FindAsync(id) ?? throw NotFound("Book", id);
        db.Books.Remove(book);
        await db.SaveChangesAsync();
        return true;
    }

    // ---------- Authors ----------

    public async Task<Author> CreateAuthor(string name, string? surname, LibraryContext db)
    {
        if (string.IsNullOrWhiteSpace(name)) throw Validation("Name is required");

        var author = new Author { Name = name, Surname = surname ?? "" };
        db.Authors.Add(author);
        await db.SaveChangesAsync();
        return author;
    }

    public async Task<Author> UpdateAuthor(int id, string name, string? surname, LibraryContext db)
    {
        var author = await db.Authors.FindAsync(id) ?? throw NotFound("Author", id);
        if (string.IsNullOrWhiteSpace(name)) throw Validation("Name is required");

        author.Name = name;
        author.Surname = surname ?? "";
        await db.SaveChangesAsync();
        return author;
    }

    public async Task<bool> DeleteAuthor(int id, LibraryContext db)
    {
        var author = await db.Authors.FindAsync(id) ?? throw NotFound("Author", id);
        if (await db.Books.AnyAsync(b => b.AuthorId == id))
            throw Conflict($"Author {id} is referenced by one or more books");

        db.Authors.Remove(author);
        await db.SaveChangesAsync();
        return true;
    }

    // ---------- Publishers ----------

    public async Task<Publisher> CreatePublisher(string name, LibraryContext db)
    {
        if (string.IsNullOrWhiteSpace(name)) throw Validation("Name is required");

        var publisher = new Publisher { Name = name };
        db.Publishers.Add(publisher);
        await db.SaveChangesAsync();
        return publisher;
    }

    public async Task<Publisher> UpdatePublisher(int id, string name, LibraryContext db)
    {
        var publisher = await db.Publishers.FindAsync(id) ?? throw NotFound("Publisher", id);
        if (string.IsNullOrWhiteSpace(name)) throw Validation("Name is required");

        publisher.Name = name;
        await db.SaveChangesAsync();
        return publisher;
    }

    public async Task<bool> DeletePublisher(int id, LibraryContext db)
    {
        var publisher = await db.Publishers.FindAsync(id) ?? throw NotFound("Publisher", id);
        if (await db.Books.AnyAsync(b => b.PublisherId == id))
            throw Conflict($"Publisher {id} is referenced by one or more books");

        db.Publishers.Remove(publisher);
        await db.SaveChangesAsync();
        return true;
    }

    // ---------- Hjælpemetoder ----------

    private static async Task ValidateBook(string title, int authorId, int publisherId, int publishingYear, LibraryContext db)
    {
        if (string.IsNullOrWhiteSpace(title)) throw Validation("Title is required");
        if (publishingYear < 1900) throw Validation("Publishing year must be 1900 or later");
        if (!await db.Authors.AnyAsync(a => a.Id == authorId)) throw Validation($"Author {authorId} does not exist");
        if (!await db.Publishers.AnyAsync(p => p.Id == publisherId)) throw Validation($"Publisher {publisherId} does not exist");
    }

    private static Task<Book> LoadBook(int id, LibraryContext db) =>
        db.Books.Include(b => b.Author).Include(b => b.Publisher).FirstAsync(b => b.Id == id);

    private static GraphQLException NotFound(string entity, int id) => Error("NOT_FOUND", $"{entity} {id} not found");
    private static GraphQLException Validation(string message) => Error("VALIDATION_ERROR", message);
    private static GraphQLException Conflict(string message) => Error("CONFLICT", message);

    private static GraphQLException Error(string code, string message) =>
        new(ErrorBuilder.New().SetMessage(message).SetCode(code).Build());
}