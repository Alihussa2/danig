using Library.Data;

var builder = WebApplication.CreateBuilder(args);

// Forbinder til ../library.db (solution-mappen)
builder.Services.AddLibraryDb(builder.Environment.ContentRootPath);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();

app.MapControllers();

app.Run();
