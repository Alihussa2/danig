using System.ComponentModel.DataAnnotations;

namespace Library.Rest.Dtos;

// ---------- Output ----------

public record BookDto(int Id, string Title, int AuthorId, int PublisherId, int PublishingYear);
public record AuthorDto(int Id, string Name, string Surname);
public record PublisherDto(int Id, string Name);
public record PagedResult<T>(IReadOnlyList<T> Items, int Total, int Limit, int Offset);

// ---------- Input (create + update) ----------
// Felterne er nullable, så et manglende felt giver 400 i stedet for stille at blive 0.

public record BookInput(
    [Required, StringLength(255, MinimumLength = 1)] string? Title,
    [Required, Range(1, int.MaxValue)] int? AuthorId,
    [Required, Range(1, int.MaxValue)] int? PublisherId,
    [Required, Range(1900, int.MaxValue, ErrorMessage = "PublishingYear must be 1900 or later.")] int? PublishingYear);

public record AuthorInput(
    [Required, StringLength(40, MinimumLength = 1)] string? Name,
    // Efternavn må være tomt (fx "Aristotle"), men skal være med i body
    [Required(AllowEmptyStrings = true), StringLength(60)] string? Surname);

public record PublisherInput(
    [Required, StringLength(40, MinimumLength = 1)] string? Name);
