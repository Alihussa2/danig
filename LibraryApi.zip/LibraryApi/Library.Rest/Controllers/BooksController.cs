using System.ComponentModel.DataAnnotations;
using Library.Data;
using Library.Rest.Dtos;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Library.Rest.Controllers;

[ApiController]
[Route("api/books")]
[Produces("application/json")]
public class BooksController(LibraryContext db) : ControllerBase
{
    private static BookDto ToDto(Book b) =>
        new(b.Id, b.Title, b.AuthorId, b.PublisherId, b.PublishingYear);

    /// <summary>List books with pagination. GET api/books?limit=10&amp;offset=0</summary>
    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<PagedResult<BookDto>>> List(
        [FromQuery, Range(1, 100)] int limit = 10,
        [FromQuery, Range(0, int.MaxValue)] int offset = 0)
    {
        var total = await db.Books.CountAsync();
        var books = await db.Books.AsNoTracking()
            .OrderBy(b => b.Id)
            .Skip(offset)
            .Take(limit)
            .ToListAsync();

        return new PagedResult<BookDto>(books.Select(ToDto).ToList(), total, limit, offset);
    }

    [HttpGet("{id:int}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<BookDto>> GetById(int id)
    {
        var book = await db.Books.FindAsync(id);
        return book is null ? NotFound() : ToDto(book);
    }

    [HttpPost]
    [ProducesResponseType(StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<BookDto>> Create(BookInput input)
    {
        if (await ValidateReferences(input) is { } error) return error;

        var book = new Book();
        Apply(book, input);
        db.Books.Add(book);
        await db.SaveChangesAsync();

        return CreatedAtAction(nameof(GetById), new { id = book.Id }, ToDto(book));
    }

    [HttpPut("{id:int}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<BookDto>> Update(int id, BookInput input)
    {
        var book = await db.Books.FindAsync(id);
        if (book is null) return NotFound();
        if (await ValidateReferences(input) is { } error) return error;

        Apply(book, input);
        await db.SaveChangesAsync();
        return ToDto(book);
    }

    [HttpDelete("{id:int}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Delete(int id)
    {
        var book = await db.Books.FindAsync(id);
        if (book is null) return NotFound();

        db.Books.Remove(book);
        await db.SaveChangesAsync();
        return NoContent();
    }

    private static void Apply(Book book, BookInput input)
    {
        book.Title = input.Title!.Trim();
        book.AuthorId = input.AuthorId!.Value;
        book.PublisherId = input.PublisherId!.Value;
        book.PublishingYear = input.PublishingYear!.Value;
    }

    // authorId og publisherId skal pege på eksisterende rækker -> ellers 400
    private async Task<ActionResult?> ValidateReferences(BookInput input)
    {
        if (!await db.Authors.AnyAsync(a => a.Id == input.AuthorId))
            ModelState.AddModelError(nameof(input.AuthorId), $"Author {input.AuthorId} does not exist.");
        if (!await db.Publishers.AnyAsync(p => p.Id == input.PublisherId))
            ModelState.AddModelError(nameof(input.PublisherId), $"Publisher {input.PublisherId} does not exist.");

        return ModelState.IsValid ? null : ValidationProblem(ModelState);
    }
}
