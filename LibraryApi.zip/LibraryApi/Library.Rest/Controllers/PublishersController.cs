using Library.Data;
using Library.Rest.Dtos;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Library.Rest.Controllers;

[ApiController]
[Route("api/publishers")]
[Produces("application/json")]
public class PublishersController(LibraryContext db) : ControllerBase
{
    private static PublisherDto ToDto(Publisher p) => new(p.Id, p.Name);

    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IEnumerable<PublisherDto>> List() =>
        (await db.Publishers.AsNoTracking().OrderBy(p => p.Id).ToListAsync()).Select(ToDto);

    [HttpGet("{id:int}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<PublisherDto>> GetById(int id)
    {
        var publisher = await db.Publishers.FindAsync(id);
        return publisher is null ? NotFound() : ToDto(publisher);
    }

    [HttpPost]
    [ProducesResponseType(StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<PublisherDto>> Create(PublisherInput input)
    {
        var publisher = new Publisher { Name = input.Name!.Trim() };
        db.Publishers.Add(publisher);
        await db.SaveChangesAsync();

        return CreatedAtAction(nameof(GetById), new { id = publisher.Id }, ToDto(publisher));
    }

    [HttpPut("{id:int}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<PublisherDto>> Update(int id, PublisherInput input)
    {
        var publisher = await db.Publishers.FindAsync(id);
        if (publisher is null) return NotFound();

        publisher.Name = input.Name!.Trim();
        await db.SaveChangesAsync();
        return ToDto(publisher);
    }

    [HttpDelete("{id:int}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Delete(int id)
    {
        var publisher = await db.Publishers.FindAsync(id);
        if (publisher is null) return NotFound();

        if (await db.Books.AnyAsync(b => b.PublisherId == id))
            return Problem(statusCode: StatusCodes.Status409Conflict, title: "Conflict",
                detail: $"Publisher {id} is referenced by one or more books.");

        db.Publishers.Remove(publisher);
        await db.SaveChangesAsync();
        return NoContent();
    }
}
