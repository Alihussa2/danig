using Library.Data;
using Library.Rest.Dtos;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Library.Rest.Controllers;

[ApiController]
[Route("api/authors")]
[Produces("application/json")]
public class AuthorsController(LibraryContext db) : ControllerBase
{
    private static AuthorDto ToDto(Author a) => new(a.Id, a.Name, a.Surname);

    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IEnumerable<AuthorDto>> List() =>
        (await db.Authors.AsNoTracking().OrderBy(a => a.Id).ToListAsync()).Select(ToDto);

    [HttpGet("{id:int}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<AuthorDto>> GetById(int id)
    {
        var author = await db.Authors.FindAsync(id);
        return author is null ? NotFound() : ToDto(author);
    }

    [HttpPost]
    [ProducesResponseType(StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<AuthorDto>> Create(AuthorInput input)
    {
        var author = new Author { Name = input.Name!.Trim(), Surname = input.Surname!.Trim() };
        db.Authors.Add(author);
        await db.SaveChangesAsync();

        return CreatedAtAction(nameof(GetById), new { id = author.Id }, ToDto(author));
    }

    [HttpPut("{id:int}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<AuthorDto>> Update(int id, AuthorInput input)
    {
        var author = await db.Authors.FindAsync(id);
        if (author is null) return NotFound();

        author.Name = input.Name!.Trim();
        author.Surname = input.Surname!.Trim();
        await db.SaveChangesAsync();
        return ToDto(author);
    }

    [HttpDelete("{id:int}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Delete(int id)
    {
        var author = await db.Authors.FindAsync(id);
        if (author is null) return NotFound();

        if (await db.Books.AnyAsync(b => b.AuthorId == id))
            return Problem(statusCode: StatusCodes.Status409Conflict, title: "Conflict",
                detail: $"Author {id} is referenced by one or more books.");

        db.Authors.Remove(author);
        await db.SaveChangesAsync();
        return NoContent();
    }
}
