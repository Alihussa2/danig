namespace Library.Data;

public class Author
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public string Surname { get; set; } = "";
    public List<Book> Books { get; set; } = new();
}

public class Publisher
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public List<Book> Books { get; set; } = new();
}

public class Book
{
    public int Id { get; set; }
    public string Title { get; set; } = "";
    public int AuthorId { get; set; }
    public Author? Author { get; set; }
    public int PublisherId { get; set; }
    public Publisher? Publisher { get; set; }
    public int PublishingYear { get; set; }
}
