using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Library.Data;

public static class ServiceCollectionExtensions
{
    // library.db ligger i solution-mappen, ét niveau over API-projektet.
    // Genbruges senere af SOAP-, GraphQL- og gRPC-projekterne.
    public static IServiceCollection AddLibraryDb(this IServiceCollection services, string contentRoot)
    {
        var dbPath = Path.GetFullPath(Path.Combine(contentRoot, "..", "library.db"));
        return services.AddDbContext<LibraryContext>(o => o.UseSqlite($"Data Source={dbPath}"));
    }
}
