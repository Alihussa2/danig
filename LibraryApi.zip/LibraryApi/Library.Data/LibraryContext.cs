using Microsoft.EntityFrameworkCore;

namespace Library.Data;

public class LibraryContext(DbContextOptions<LibraryContext> options) : DbContext(options)
{
    public DbSet<Book> Books => Set<Book>();
    public DbSet<Author> Authors => Set<Author>();
    public DbSet<Publisher> Publishers => Set<Publisher>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        // Mapping til skemaet i library.db (tauthor, tpublishingcompany, tbook)
        b.Entity<Author>(e =>
        {
            e.ToTable("tauthor");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).HasColumnName("nAuthorID");
            e.Property(x => x.Name).HasColumnName("cName").HasMaxLength(40);
            e.Property(x => x.Surname).HasColumnName("cSurname").HasMaxLength(60);
        });

        b.Entity<Publisher>(e =>
        {
            e.ToTable("tpublishingcompany");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).HasColumnName("nPublishingCompanyID");
            e.Property(x => x.Name).HasColumnName("cName").HasMaxLength(40);
        });

        b.Entity<Book>(e =>
        {
            e.ToTable("tbook");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).HasColumnName("nBookID");
            e.Property(x => x.Title).HasColumnName("cTitle").HasMaxLength(255);
            e.Property(x => x.AuthorId).HasColumnName("nAuthorID");
            e.Property(x => x.PublisherId).HasColumnName("nPublishingCompanyID");
            e.Property(x => x.PublishingYear).HasColumnName("nPublishingYear");

            e.HasOne(x => x.Author).WithMany(a => a.Books)
                .HasForeignKey(x => x.AuthorId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Publisher).WithMany(p => p.Books)
                .HasForeignKey(x => x.PublisherId).OnDelete(DeleteBehavior.Restrict);
        });
    }
}
