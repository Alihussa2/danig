﻿using System.Collections.Concurrent;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;
using Library.Soap1.Contracts;

namespace Library.Soap1;

// HTTP-endpointet for SOAP 1.1 (document/literal)
public static class SoapEndpoint
{
    // Namespaces: vores eget (fra WSDL'en) og SOAP-konvoluttens
    public const string Ns = "http://library.ek.dk/soap";
    private static readonly XNamespace SoapNs = "http://schemas.xmlsoap.org/soap/envelope/";
    private static readonly XNamespace TNs = Ns;

    // En operation = hvilken request-klasse den tager + hvilken service-metode der skal kaldes
    private record Operation(Type RequestType, Func<LibrarySoapService, object, Task<object>> Invoke);

    // ===== Alle 14 operationer: navn -> request-type, response-type og service-metode =====
    private static readonly Dictionary<string, Operation> Operations = new()
    {
        ["CreateBook"] = Op<CreateBookRequest, IdResponse>((s, r) => s.CreateBook(r)),
        ["GetBookById"] = Op<IdRequest, GetBookByIdResponse>((s, r) => s.GetBookById(r)),
        ["UpdateBook"] = Op<UpdateBookRequest, Acknowledgement>((s, r) => s.UpdateBook(r)),
        ["DeleteBook"] = Op<IdRequest, Acknowledgement>((s, r) => s.DeleteBook(r)),
        
        // Author
        ["CreateAuthor"] = Op<CreateAuthorRequest, IdResponse>((s, r) => s.CreateAuthor(r)),
        ["GetAuthorById"] = Op<IdRequest, GetAuthorByIdResponse>((s, r) => s.GetAuthorById(r)),
        ["ListAuthors"] = Op<EmptyRequest, ListAuthorsResponse>((s, r) => s.ListAuthors(r)),
        ["UpdateAuthor"] = Op<UpdateAuthorRequest, Acknowledgement>((s, r) => s.UpdateAuthor(r)),
        ["DeleteAuthor"] = Op<IdRequest, Acknowledgement>((s, r) => s.DeleteAuthor(r)),

        // PublishingCompany
        ["CreatePublishingCompany"] = Op<CreatePublishingCompanyRequest, IdResponse>((s, r) => s.CreatePublishingCompany(r)),
        ["GetPublishingCompanyById"] = Op<IdRequest, GetPublishingCompanyByIdResponse>((s, r) => s.GetPublishingCompanyById(r)),
        ["ListPublishingCompanies"] = Op<EmptyRequest, ListPublishingCompaniesResponse>((s, r) => s.ListPublishingCompanies(r)),
        ["UpdatePublishingCompany"] = Op<UpdatePublishingCompanyRequest, Acknowledgement>((s, r) => s.UpdatePublishingCompany(r)),
        ["DeletePublishingCompany"] = Op<IdRequest, Acknowledgement>((s, r) => s.DeletePublishingCompany(r)),
    };

    // Hjælper, der pakker en service-metode ind som en Operation
    private static Operation Op<TReq, TRes>(Func<LibrarySoapService, TReq, Task<TRes>> method) where TRes : class =>
        new(typeof(TReq), async (service, request) => await method(service, (TReq)request));

    // ===================== POST /soap =====================
    public static async Task HandleAsync(HttpContext ctx, LibrarySoapService service)
    {
        XElement result;
        var status = StatusCodes.Status200OK;
        try
        {
            result = await Dispatch(ctx, service);              // trin 1-5 herunder
        }
        catch (SoapFaultException fault)                          // vores egne fejl -> typet fault
        {
            result = Fault("soap:Client", fault.Message, fault.FaultName);
            status = StatusCodes.Status500InternalServerError;    // SOAP 1.1: faults sendes med HTTP 500
        }
        catch (Exception ex)                                      // alt andet -> generel serverfejl
        {
            ctx.RequestServices.GetRequiredService<ILogger<LibrarySoapService>>().LogError(ex, "Unexpected SOAP error");
            result = Fault("soap:Server", "Unexpected server error", null);
            status = StatusCodes.Status500InternalServerError;
        }

        // Læg resultatet i en ny <soap:Envelope><soap:Body>…</soap:Body></soap:Envelope>
        var envelope = new XDocument(
            new XDeclaration("1.0", "utf-8", null),
            new XElement(SoapNs + "Envelope",
                new XAttribute(XNamespace.Xmlns + "soap", SoapNs),
                new XElement(SoapNs + "Body", result)));

        ctx.Response.StatusCode = status;
        ctx.Response.ContentType = "text/xml; charset=utf-8";
        await ctx.Response.WriteAsync(envelope.Declaration + envelope.ToString(SaveOptions.DisableFormatting));
    }

    private static async Task<XElement> Dispatch(HttpContext ctx, LibrarySoapService service)
    {
        // ----- 1. Læs XML'en og find <soap:Body> -----
        XDocument doc;
        try { doc = await XDocument.LoadAsync(ctx.Request.Body, LoadOptions.None, ctx.RequestAborted); }
        catch (XmlException ex) { throw SoapFaultException.Validation($"Malformed XML: {ex.Message}"); }

        var body = doc.Root?.Name == SoapNs + "Envelope" ? doc.Root.Element(SoapNs + "Body") : null;
        if (body is null) throw SoapFaultException.Validation("Request must be a SOAP 1.1 <soap:Envelope> with a <soap:Body>");

        // ----- 2. Find operationen ud fra navnet på første element -----
        var requestElement = body.Elements().FirstOrDefault()
            ?? throw SoapFaultException.Validation("<soap:Body> is empty");
        var elementName = requestElement.Name.LocalName;                 // fx "GetBookByIdRequest"
        var operationName = elementName.EndsWith("Request")
            ? elementName[..^"Request".Length]                           // -> "GetBookById"
            : elementName;

        if (requestElement.Name.Namespace != TNs || !Operations.TryGetValue(operationName, out var operation))
            throw SoapFaultException.Validation($"Unknown operation {{{requestElement.Name.NamespaceName}}}{elementName}");

        // Tilgiv klienter, der glemmer namespace på under-elementerne (<id> i stedet for <lib:id>)
        foreach (var child in requestElement.Descendants().Where(e => e.Name.Namespace == XNamespace.None))
            child.Name = TNs + child.Name.LocalName;

        // ----- 3. XML -> C#-objekt -----
        object request;
        try
        {
            using var reader = requestElement.CreateReader();
            request = Serializer(operation.RequestType, operationName + "Request").Deserialize(reader)!;
        }
        catch (InvalidOperationException ex)   // fx <id>abc</id>
        {
            throw SoapFaultException.Validation($"Invalid value in request: {ex.InnerException?.Message ?? ex.Message}");
        }

        // ----- 4. Kald servicen -----
        var response = await operation.Invoke(service, request);

        // ----- 5. C#-objekt -> XML -----
        return ToXElement(response, operationName + "Response");
    }

    // <soap:Fault> med typet detail, fx <tns:NotFoundFault><tns:message>…</tns:message></tns:NotFoundFault>
    private static XElement Fault(string faultCode, string message, string? faultName)
    {
        var fault = new XElement(SoapNs + "Fault",
            new XElement("faultcode", faultCode),
            new XElement("faultstring", message));

        if (faultName is not null)
            fault.Add(new XElement("detail",
                new XElement(TNs + faultName,
                    new XAttribute(XNamespace.Xmlns + "tns", Ns),
                    new XElement(TNs + "message", message))));

        return fault;
    }

    // ===================== XmlSerializer-hjælpere =====================

    // Serializers gemmes, så de kun laves én gang (det er langsomt at lave dem)
    private static readonly ConcurrentDictionary<(Type, string), XmlSerializer> Serializers = new();

    private static XmlSerializer Serializer(Type type, string rootElement) =>
        Serializers.GetOrAdd((type, rootElement), key =>
            new XmlSerializer(key.Item1, null, Type.EmptyTypes, new XmlRootAttribute(key.Item2) { Namespace = Ns }, Ns));

    private static XElement ToXElement(object value, string rootElement)
    {
        var namespaces = new XmlSerializerNamespaces();
        namespaces.Add("", Ns);   // brug vores namespace som standard, uden xsi/xsd-støj

        var doc = new XDocument();
        using (var writer = doc.CreateWriter())
            Serializer(value.GetType(), rootElement).Serialize(writer, value, namespaces);
        return doc.Root!;
    }
}