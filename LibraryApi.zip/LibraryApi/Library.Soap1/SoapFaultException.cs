﻿namespace Library.Soap1;

// En fejl, der skal sendes tilbage som <soap:Fault>.
// FaultName er navnet fra WSDL'en: NotFoundFault, ValidationFault eller ConflictFault.
public class SoapFaultException(string faultName, string message) : Exception(message)
{
    public string FaultName { get; } = faultName;

    // Det id, der spørges om, findes ikke
    public static SoapFaultException NotFound(string message) => new("NotFoundFault", message);

    // Felter mangler, er ugyldige eller peger på noget, der ikke findes
    public static SoapFaultException Validation(string message) => new("ValidationFault", message);

    // Man prøver at slette noget, som andre rækker stadig bruger
    public static SoapFaultException Conflict(string message) => new("ConflictFault", message);
}