﻿using System.Xml.Serialization;

namespace Library.Soap1.Contracts;

// ===================== XSD-typer =====================

// XSD-typen "Book" fra WSDL'en
[XmlType("Book")]
public class BookType
{
    [XmlElement("id")] public int Id { get; set; }
    [XmlElement("title")] public string Title { get; set; } = "";
    [XmlElement("authorId")] public int AuthorId { get; set; }
    [XmlElement("publishingCompanyId")] public int PublishingCompanyId { get; set; }
    [XmlElement("publishingYear")] public int PublishingYear { get; set; }
}

// Svaret fra alle Update- og Delete-operationer
public class Acknowledgement
{
    [XmlElement("success")] public bool Success { get; set; } = true;
    [XmlElement("message")] public string Message { get; set; } = "";
}

// ===================== Requests =====================

// Request med kun et id: GetBookById, DeleteBook (senere også GetAuthorById …)
public class IdRequest
{
    [XmlElement("id")] public int? Id { get; set; }
}

// Felterne, som både CreateBook og UpdateBook har.
// Nullable (?), så et manglende felt bliver null -> ValidationFault
public class BookFields
{
    [XmlElement("title")] public string? Title { get; set; }
    [XmlElement("authorId")] public int? AuthorId { get; set; }
    [XmlElement("publishingCompanyId")] public int? PublishingCompanyId { get; set; }
    [XmlElement("publishingYear")] public int? PublishingYear { get; set; }
}

public class CreateBookRequest : BookFields { }

public class UpdateBookRequest : BookFields
{
    [XmlElement("id")] public int? Id { get; set; }
}

// ===================== Responses =====================

// Svaret fra alle Create-operationer: det nye id
public class IdResponse
{
    [XmlElement("id")] public int Id { get; set; }
}

// Svaret fra GetBookById: <GetBookByIdResponse><book>…</book></GetBookByIdResponse>
public class GetBookByIdResponse
{
    [XmlElement("book")] public BookType Book { get; set; } = new();
}

// ===================== Author (NY) =====================

// XSD-typen "Author" fra WSDL'en
[XmlType("Author")]
public class AuthorType
{
    [XmlElement("id")] public int Id { get; set; }
    [XmlElement("name")] public string Name { get; set; } = "";
    [XmlElement("surname")] public string Surname { get; set; } = "";
}

// Felterne, som både CreateAuthor og UpdateAuthor har
public class AuthorFields
{
    [XmlElement("name")] public string? Name { get; set; }
    [XmlElement("surname")] public string? Surname { get; set; }
}

public class CreateAuthorRequest : AuthorFields { }

public class UpdateAuthorRequest : AuthorFields
{
    [XmlElement("id")] public int? Id { get; set; }
}

// Tom request: ListAuthors (og senere ListPublishingCompanies)
public class EmptyRequest { }

// Svaret fra GetAuthorById: <GetAuthorByIdResponse><author>…</author></GetAuthorByIdResponse>
public class GetAuthorByIdResponse
{
    [XmlElement("author")] public AuthorType Author { get; set; } = new();
}

// Svaret fra ListAuthors: <ListAuthorsResponse><author>…</author><author>…</author>…</ListAuthorsResponse>
public class ListAuthorsResponse
{
    [XmlElement("author")] public List<AuthorType> Authors { get; set; } = new();
}

// ===================== PublishingCompany (NY) =====================

// XSD-typen "PublishingCompany" fra WSDL'en
[XmlType("PublishingCompany")]
public class PublishingCompanyType
{
    [XmlElement("id")] public int Id { get; set; }
    [XmlElement("name")] public string Name { get; set; } = "";
}

public class CreatePublishingCompanyRequest
{
    [XmlElement("name")] public string? Name { get; set; }
}

public class UpdatePublishingCompanyRequest
{
    [XmlElement("id")] public int? Id { get; set; }
    [XmlElement("name")] public string? Name { get; set; }
}

// Svaret fra GetPublishingCompanyById: <GetPublishingCompanyByIdResponse><publishingCompany>…</publishingCompany></GetPublishingCompanyByIdResponse>
public class GetPublishingCompanyByIdResponse
{
    [XmlElement("publishingCompany")] public PublishingCompanyType PublishingCompany { get; set; } = new();
}

// Svaret fra ListPublishingCompanies: <ListPublishingCompaniesResponse><publishingCompany>…</publishingCompany>…</ListPublishingCompaniesResponse>
public class ListPublishingCompaniesResponse
{
    [XmlElement("publishingCompany")] public List<PublishingCompanyType> PublishingCompanies { get; set; } = new();
}
