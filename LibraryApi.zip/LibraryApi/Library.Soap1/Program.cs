﻿using Library.Data;
using Library.Soap1;

var builder = WebApplication.CreateBuilder(args);

// Samme database som de andre API'er: ../library.db (solution-mappen)
builder.Services.AddLibraryDb(builder.Environment.ContentRootPath);

// SOAP-operationerne (én instans pr. request, ligesom LibraryContext)
builder.Services.AddScoped<LibrarySoapService>();

var app = builder.Build();

// Læs WSDL-filen én gang ved opstart
var wsdl = File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "library.wsdl"));

// GET /soap?wsdl -> kontrakten (XSD-typer, operationer og faults) med den rigtige adresse indsat
app.MapGet("/soap", (HttpRequest req) =>
    Results.Text(wsdl.Replace("__SOAP_URL__", $"{req.Scheme}://{req.Host}/soap"),
        "text/xml; charset=utf-8"));

// POST /soap -> SOAP-operationerne (se SoapEndpoint.cs)
app.MapPost("/soap", SoapEndpoint.HandleAsync);

// Forsiden sender videre til WSDL'en
app.MapGet("/", () => Results.Redirect("/soap?wsdl"));

app.Run();
