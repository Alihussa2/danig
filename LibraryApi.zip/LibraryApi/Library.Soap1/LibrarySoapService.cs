﻿using Library.Data;
using Library.Soap1.Contracts;
using Microsoft.EntityFrameworkCore;   // NY: bruges til AnyAsync

namespace Library.Soap1;

// SOAP-operationerne. Kun forretningslogik: ingen XML her.
public class LibrarySoapService(LibraryContext db)
{
    // ===================== Book =====================

    public async Task<GetBookByIdResponse> GetBookById(IdRequest request)
    {
        // 1. Er id'et sendt med og gyldigt?
        if (request.Id is null or <= 0)
            throw SoapFaultException.Validation("id is required and must be a positive integer");

        // 2. Find bogen i databasen
        var book = await db.Books.FindAsync(request.Id.Value);

        // 3. Findes den ikke -> NotFoundFault
        if (book is null)
            throw SoapFaultException.NotFound($"Book with id {request.Id} does not exist");

        // 4. Lav database-entiteten om til XSD-typen og returnér
        return new GetBookByIdResponse { Book = ToXml(book) };
    }

    // ----- NY -----
    public async Task<IdResponse> CreateBook(CreateBookRequest r)
    {
        await ValidateBook(r);                 // ValidationFault hvis noget er galt
        var book = new Book();
        Apply(book, r);                        // kopier felterne over
        db.Books.Add(book);
        await db.SaveChangesAsync();           // databasen giver bogen et id her
        return new IdResponse { Id = book.Id };
    }

    // ----- NY -----
    public async Task<Acknowledgement> UpdateBook(UpdateBookRequest r)
    {
        var book = await FindBook(r.Id);       // NotFoundFault hvis den ikke findes
        await ValidateBook(r);
        Apply(book, r);
        await db.SaveChangesAsync();           // EF ser ændringerne og laver en UPDATE
        return Ok($"Book {book.Id} updated");
    }

    // ----- NY -----
    public async Task<Acknowledgement> DeleteBook(IdRequest r)
    {
        var book = await FindBook(r.Id);
        db.Books.Remove(book);
        await db.SaveChangesAsync();
        return Ok($"Book {book.Id} deleted");
    }

    // ===================== Author (NY) =====================

    public async Task<IdResponse> CreateAuthor(CreateAuthorRequest r)
    {
        ValidateAuthor(r);                      // ValidationFault hvis noget er galt
        var author = new Author { Name = r.Name!.Trim(), Surname = r.Surname!.Trim() };
        db.Authors.Add(author);
        await db.SaveChangesAsync();            // databasen giver forfatteren et id her
        return new IdResponse { Id = author.Id };
    }

    public async Task<GetAuthorByIdResponse> GetAuthorById(IdRequest r)
    {
        var author = await FindAuthor(r.Id);    // NotFoundFault hvis den ikke findes
        return new GetAuthorByIdResponse { Author = ToXml(author) };
    }

    public async Task<ListAuthorsResponse> ListAuthors(EmptyRequest _)
    {
        var authors = await db.Authors.OrderBy(a => a.Id).ToListAsync();
        return new ListAuthorsResponse { Authors = authors.Select(ToXml).ToList() };
    }

    public async Task<Acknowledgement> UpdateAuthor(UpdateAuthorRequest r)
    {
        var author = await FindAuthor(r.Id);
        ValidateAuthor(r);
        author.Name = r.Name!.Trim();
        author.Surname = r.Surname!.Trim();
        await db.SaveChangesAsync();
        return Ok($"Author {author.Id} updated");
    }

    public async Task<Acknowledgement> DeleteAuthor(IdRequest r)
    {
        var author = await FindAuthor(r.Id);

        // ConflictFault: forfatteren må ikke slettes, hvis en bog stadig peger på den
        var bookCount = await db.Books.CountAsync(b => b.AuthorId == author.Id);
        if (bookCount > 0)
            throw SoapFaultException.Conflict($"Author {author.Id} cannot be deleted: referenced by {bookCount} book(s)");

        db.Authors.Remove(author);
        await db.SaveChangesAsync();
        return Ok($"Author {author.Id} deleted");
    }

    // ===================== PublishingCompany (NY) =====================

    public async Task<IdResponse> CreatePublishingCompany(CreatePublishingCompanyRequest r)
    {
        var publisher = new Publisher { Name = ValidateName(r.Name) };   // ValidationFault hvis navnet er ugyldigt
        db.Publishers.Add(publisher);
        await db.SaveChangesAsync();                                     // databasen giver forlaget et id her
        return new IdResponse { Id = publisher.Id };
    }

    public async Task<GetPublishingCompanyByIdResponse> GetPublishingCompanyById(IdRequest r)
    {
        var publisher = await FindPublisher(r.Id);                       // NotFoundFault hvis det ikke findes
        return new GetPublishingCompanyByIdResponse { PublishingCompany = ToXml(publisher) };
    }

    public async Task<ListPublishingCompaniesResponse> ListPublishingCompanies(EmptyRequest _)
    {
        var publishers = await db.Publishers.OrderBy(p => p.Id).ToListAsync();
        return new ListPublishingCompaniesResponse { PublishingCompanies = publishers.Select(ToXml).ToList() };
    }

    public async Task<Acknowledgement> UpdatePublishingCompany(UpdatePublishingCompanyRequest r)
    {
        var publisher = await FindPublisher(r.Id);
        publisher.Name = ValidateName(r.Name);
        await db.SaveChangesAsync();
        return Ok($"Publishing company {publisher.Id} updated");
    }

    public async Task<Acknowledgement> DeletePublishingCompany(IdRequest r)
    {
        var publisher = await FindPublisher(r.Id);

        // ConflictFault: forlaget må ikke slettes, hvis en bog stadig peger på det
        var bookCount = await db.Books.CountAsync(b => b.PublisherId == publisher.Id);
        if (bookCount > 0)
            throw SoapFaultException.Conflict($"Publishing company {publisher.Id} cannot be deleted: referenced by {bookCount} book(s)");

        db.Publishers.Remove(publisher);
        await db.SaveChangesAsync();
        return Ok($"Publishing company {publisher.Id} deleted");
    }

    // ===================== Hjælpere =====================

    // ----- NY: "succes"-svaret til Update og Delete -----
    private static Acknowledgement Ok(string message) => new() { Success = true, Message = message };

    // ----- NY: tjek at id er sendt og > 0 -----
    private static int RequireId(int? id) =>
        id is > 0 ? id.Value : throw SoapFaultException.Validation("id is required and must be a positive integer");

    // ----- NY: find bog eller kast NotFoundFault -----
    private async Task<Book> FindBook(int? id)
    {
        var bookId = RequireId(id);
        return await db.Books.FindAsync(bookId)
            ?? throw SoapFaultException.NotFound($"Book with id {bookId} does not exist");
    }

    // ----- NY: alle reglerne for en bog. Kaster ValidationFault ved første fejl -----
    private async Task ValidateBook(BookFields r)
    {
        if (string.IsNullOrWhiteSpace(r.Title)) throw SoapFaultException.Validation("title is required");
        if (r.Title.Length > 255) throw SoapFaultException.Validation("title must be at most 255 characters");
        if (r.AuthorId is null) throw SoapFaultException.Validation("authorId is required");
        if (r.PublishingCompanyId is null) throw SoapFaultException.Validation("publishingCompanyId is required");
        if (r.PublishingYear is null) throw SoapFaultException.Validation("publishingYear is required");
        if (r.PublishingYear < 1900) throw SoapFaultException.Validation("publishingYear must be 1900 or later");
        if (r.PublishingYear > DateTime.Now.Year) throw SoapFaultException.Validation("publishingYear cannot be in the future");

        // Skal pege på noget, der findes
        if (!await db.Authors.AnyAsync(a => a.Id == r.AuthorId))
            throw SoapFaultException.Validation($"authorId {r.AuthorId} does not reference an existing author");
        if (!await db.Publishers.AnyAsync(p => p.Id == r.PublishingCompanyId))
            throw SoapFaultException.Validation($"publishingCompanyId {r.PublishingCompanyId} does not reference an existing publishing company");
    }

    // ----- NY: kopier felterne fra requesten over på database-entiteten -----
    private static void Apply(Book book, BookFields r)
    {
        book.Title = r.Title!.Trim();
        book.AuthorId = r.AuthorId!.Value;
        book.PublisherId = r.PublishingCompanyId!.Value;
        book.PublishingYear = r.PublishingYear!.Value;
    }

    // ----- Author-hjælpere (NY) -----

    // Find forfatter eller kast NotFoundFault
    private async Task<Author> FindAuthor(int? id)
    {
        var authorId = RequireId(id);
        return await db.Authors.FindAsync(authorId)
            ?? throw SoapFaultException.NotFound($"Author with id {authorId} does not exist");
    }

    // Reglerne for en forfatter
    private static void ValidateAuthor(AuthorFields r)
    {
        if (string.IsNullOrWhiteSpace(r.Name)) throw SoapFaultException.Validation("name is required");
        if (r.Name.Length > 40) throw SoapFaultException.Validation("name must be at most 40 characters");

        // Efternavn skal sendes med, men må være tomt (fx "Aristotle")
        if (r.Surname is null) throw SoapFaultException.Validation("surname is required (send an empty <surname/> if none)");
        if (r.Surname.Length > 60) throw SoapFaultException.Validation("surname must be at most 60 characters");
    }

    // Author (database) -> AuthorType (SOAP/XML)
    private static AuthorType ToXml(Author a) => new() { Id = a.Id, Name = a.Name, Surname = a.Surname };

    // ----- PublishingCompany-hjælpere (NY) -----

    // Find forlag eller kast NotFoundFault
    private async Task<Publisher> FindPublisher(int? id)
    {
        var publisherId = RequireId(id);
        return await db.Publishers.FindAsync(publisherId)
            ?? throw SoapFaultException.NotFound($"Publishing company with id {publisherId} does not exist");
    }

    // Navnet skal være udfyldt og højst 40 tegn
    private static string ValidateName(string? name)
    {
        if (string.IsNullOrWhiteSpace(name)) throw SoapFaultException.Validation("name is required");
        if (name.Length > 40) throw SoapFaultException.Validation("name must be at most 40 characters");
        return name.Trim();
    }

    // Publisher (database) -> PublishingCompanyType (SOAP/XML)
    private static PublishingCompanyType ToXml(Publisher p) => new() { Id = p.Id, Name = p.Name };

    // Book (database) -> BookType (SOAP/XML)
    private static BookType ToXml(Book b) => new()
    {
        Id = b.Id,
        Title = b.Title,
        AuthorId = b.AuthorId,
        PublishingCompanyId = b.PublisherId,   // din kammerat kalder den PublisherId
        PublishingYear = b.PublishingYear
    };
}